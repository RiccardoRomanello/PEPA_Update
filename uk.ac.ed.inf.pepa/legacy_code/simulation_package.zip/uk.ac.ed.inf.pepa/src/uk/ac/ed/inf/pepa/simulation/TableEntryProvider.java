package uk.ac.ed.inf.pepa.simulation;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import uk.ac.ed.inf.pepa.model.Action;
import uk.ac.ed.inf.pepa.model.ActionSet;
import uk.ac.ed.inf.pepa.model.Aggregation;
import uk.ac.ed.inf.pepa.model.Choice;
import uk.ac.ed.inf.pepa.model.Constant;
import uk.ac.ed.inf.pepa.model.Cooperation;
import uk.ac.ed.inf.pepa.model.Hiding;
import uk.ac.ed.inf.pepa.model.PassiveRate;
import uk.ac.ed.inf.pepa.model.Prefix;
import uk.ac.ed.inf.pepa.model.Visitor;

public class TableEntryProvider implements Visitor {

	int label;

	final SimulationModel model;

	private ArrayList<TableEntry> entries = new ArrayList<TableEntry>();

	TableEntryProvider(int label, SimulationModel model) {
		this.label = label;
		this.model = model;
	}

	public List<TableEntry> getEntries() {

		return entries;
	}

	public void visitAggregation(Aggregation aggregation) {
		// TODO Auto-generated method stub

	}

	public void visitChoice(Choice choice) {
		// TODO Auto-generated method stub

	}

	public void visitConstant(Constant constant) {
		// print(constant);

		LabelledVisitor v = new LabelledVisitor(model.components.get(label));

		/*
		 * This constant may represent a choice, so the table may have multiple
		 * entries for a particular action type. This piece of code makes the
		 * decision according to the delays of each entry. The activity that
		 * completes is the fastest, if the rate is finite. For those entries
		 * whose rate is passive a choice is made according to the assigned
		 * weights.
		 * 
		 * This resolves the race condition at the component's level (race
		 * between choices of the same type)
		 */
		entries.addAll(makeChoices(v.entries));
	}

	/**
	 * @see #visitConstant(Constant)
	 */
	private List<TableEntry> makeChoices(List<TableEntry> entries) {
		/*
		 * Note, it is not possible that two entries with the same action type
		 * have passive and active rates. Rate types are homogeneous for an
		 * action type in this scope
		 */
		List<TableEntry> tempPassiveEntries = new ArrayList<TableEntry>();

		List<TableEntry> selectedEntries = new ArrayList<TableEntry>();

		// log("\tMaking choices");
		for (TableEntry entry : entries) {
			Action currentAction = entry.action;

			boolean alreadySelected = false;
			for (TableEntry alreadySelectedEntry : selectedEntries) {
				if (alreadySelectedEntry.action.equals(currentAction)) {
					alreadySelected = true;
					break;
				}
			}
			if (alreadySelected)
				continue;

			// log("\t" + entry);

			boolean isPassive = (entry.rate instanceof PassiveRate);
			Double fastest = Double.POSITIVE_INFINITY;
			double sum = 0;
			TableEntry fastestEntry = null;
			if (isPassive)
				tempPassiveEntries.clear();
			for (TableEntry other : entries) {
				/*
				 * Only interested in other entries with the same action type
				 */
				if ((!other.action.equals(currentAction)))
					continue;
				if (isPassive) {
					sum += ((PassiveRate) other.rate).getWeight();
					tempPassiveEntries.add(other);
				} else {
					double newDelay = other.computeDelay();
					if (newDelay < fastest) {
						fastest = newDelay;
						fastestEntry = other;
					}
				}
				// log("\t\t" + other);

			}
			if (isPassive) {
				selectedEntries.add(makeChoiceForPassive(sum,
						tempPassiveEntries));
			} else {
				// log("\t\tSelected: " + fastestEntry);
				selectedEntries.add(fastestEntry);
			}
		}
		tempPassiveEntries = null;
		return selectedEntries;
	}

	private TableEntry makeChoiceForPassive(double sum,
			List<TableEntry> tempPassiveEntries) {
		// log("\t\tSum: " + sum);
		// TODO Change this with a SSJ's call
		double rand = Math.random() * sum;
		// log("\t\tRandom: " + rand);

		double offset = 0;
		TableEntry selectedEntry = null;
		for (TableEntry passiveEntry : tempPassiveEntries) {
			double currentWeigth = ((PassiveRate) passiveEntry.rate)
					.getWeight();
			// log("\t\t\tCurrent: " + currentWeigth);
			// log("\t\t\tOffset: " + offset);

			if (rand >= offset && rand < offset + currentWeigth) {
				selectedEntry = passiveEntry;
				break;
			}
			offset += currentWeigth;
		}
		// log("\t\tSelected: " + selectedEntry);
		return selectedEntry;
	}

	/*
	 * private void print(uk.ac.ed.inf.pepa.model.Process p) {
	 * log(p.prettyPrint() + ": " + label); }
	 */

	public void visitCooperation(Cooperation cooperation) {
		// print(cooperation);
		TableEntryProvider lhs = new TableEntryProvider(label + 1, model);
		cooperation.getLeftHandSide().accept(lhs);
		TableEntryProvider rhs = new TableEntryProvider(lhs.label + 1, model);
		cooperation.getRightHandSide().accept(rhs);
		SimulationModel.log("\n\nCooperation: " + cooperation.prettyPrint());
		SimulationModel.log("Left: ");
		print_entries(lhs.entries);
		SimulationModel.log("Right: ");
		print_entries(rhs.entries);
		
		entries.addAll(lhs.entries);
		entries.addAll(rhs.entries);
		SimulationModel.log("All entries: ");
		print_entries(entries);
		synchronise(lhs.entries, rhs.entries, cooperation.getActionSet());
		label = rhs.label;
	}

	/**
	 * Synchronises shared table entries
	 * 
	 * @param lhs
	 *            entries of a cooperation's lhs
	 * @param rhs
	 *            entries of a cooperation's rhs
	 * @param actions
	 *            set of shared actions
	 */
	private void synchronise(List<TableEntry> lhs, List<TableEntry> rhs,
			ActionSet actions) {

		/*
		 * TODO Performance Hot Spot Possible performance hot spot here Entries
		 * should cache the shared actions
		 */
		Iterator<Action> i = actions.iterator();
		while (i.hasNext()) {
			Action sharedAction = i.next();
			TableEntry first = null;
			for (TableEntry e : lhs) { // visiting lhs
				if (e.action.equals(sharedAction)) {
					if (first == null) {
						first = e;
					}
					e.synchronisation = first;
				}
			}
			for (TableEntry e : rhs) {
				if (e.action.equals(sharedAction)) {
					if (first == null) {
						first = e;
					}
					e.synchronisation = first;
				}
			}
		}
	}

	public void visitHiding(Hiding hiding) {
		// TODO Auto-generated method stub

	}

	public void visitPrefix(Prefix prefix) {
		entries
				.addAll(new LabelledVisitor(model.components.get(label)).entries);
	}

	private void print_entries(List<TableEntry> pEntries) {
		for (TableEntry entry : pEntries) {
			SimulationModel.log("***");
			SimulationModel.log(entry.toString());
		}
	}

}
