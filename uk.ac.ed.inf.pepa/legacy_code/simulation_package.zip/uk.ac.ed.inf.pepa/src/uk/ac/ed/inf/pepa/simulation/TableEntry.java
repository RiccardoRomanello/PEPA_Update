package uk.ac.ed.inf.pepa.simulation;

import uk.ac.ed.inf.pepa.model.Action;
import uk.ac.ed.inf.pepa.model.FiniteRate;
import uk.ac.ed.inf.pepa.model.PassiveRate;
import uk.ac.ed.inf.pepa.model.Process;
import uk.ac.ed.inf.pepa.model.Rate;

/**
 * Represents an entry in the transition table
 * 
 * @author mtribast
 * 
 */
public final class TableEntry {
	
	final static TempRateManager mng = new TempRateManager();
	
	/**
	 * Computed delay for this entry
	 */
	private double delay;

	/**
	 * The action type
	 */
	Action action;
	
	/**
	 * The rate
	 */
	Rate rate;
	
	/**
	 * The component which is subject to change
	 */
	Component component;
	
	/**
	 * The new local state for {@link #component}
	 */
	Process process;

	/**
	 * Table entry representing the process this action cooperates with to carry
	 * out the activity.
	 * 
	 */
	TableEntry synchronisation;
	
	/**
	 * Create a table entry synchronising with nobody
	 * 
	 * @param action
	 * @param component
	 * @param process
	 */
	TableEntry(Action action, Rate rate, Component component, Process process) {
		this.action = action;
		this.rate = rate;
		this.component = component;
		this.process = process;
		
		if (rate instanceof PassiveRate) {
			delay = Double.POSITIVE_INFINITY;
		} else {
			delay = mng.getSample((FiniteRate) rate);
			/*System.err.println(
					"(" + component.state.prettyPrint() + 
					", " + action.prettyPrint() + 
					"): " + delay);*/
		}
	}
	
	public double computeDelay() {
		return delay;
	}

	public void setDelay(double delay) {
		this.delay = delay;
	}

	public String toString() {
		return //super.toString() + 
				" [ ACTION: "
				+ action.prettyPrint()
				+ " RATE: " 
				+ rate.prettyPrint()
				+ " DELAY: "
				+ delay
				+ " COMPONENT_ID: "
				+ component.position
				+ " NEXT_LOCAL_STATE: "
				+ process.prettyPrint()
				+ " SYNC: "
				+ ((synchronisation == null) ? ""
						: synchronisation.component.position) + " ] ";
	}

}
