package uk.ac.ed.inf.pepa.simulation;

import java.util.HashMap;

import uk.ac.ed.inf.pepa.model.FiniteRate;
import umontreal.iro.lecuyer.rng.MRG32k3a;
import umontreal.iro.lecuyer.rng.RandomStream;

/**
 * Temporarily handles random number generators.
 * <p>
 * It supports exponential distributions only. This will be
 * changed with a more powerful framework supporting other
 * distributions.
 * 
 * @author mtribast
 *
 */
public final class TempRateManager {
	
	private HashMap<FiniteRate, RandomStream> map = 
		new HashMap<FiniteRate, RandomStream>();
	
	TempRateManager() {
	}
	
	/**
	 * The lazy initialisator for this class, called
	 * at each new simulation run, resets the streams
	 * to the next substream. If we don't do that, we will
	 * get less variance in the simulation results.
	 *
	 */
	public void lazyInit() {
		for (RandomStream stream : map.values())
			stream.resetNextSubstream();
	}
	
	public double getSample(FiniteRate rate) {
		RandomStream stream = null;
		
		stream = map.get(rate);
		if (stream == null) {
			stream = new MRG32k3a();
			map.put(rate, stream);
		}
		
		return - Math.log(1.0 - stream.nextDouble()) / rate.getValue();
		
	}
	
}
