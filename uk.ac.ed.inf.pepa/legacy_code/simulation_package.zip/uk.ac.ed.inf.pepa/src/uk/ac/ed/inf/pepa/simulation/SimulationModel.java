package uk.ac.ed.inf.pepa.simulation;

import java.util.HashMap;

import uk.ac.ed.inf.pepa.model.Action;
import uk.ac.ed.inf.pepa.model.Choice;
import uk.ac.ed.inf.pepa.model.Constant;
import uk.ac.ed.inf.pepa.model.Cooperation;
import uk.ac.ed.inf.pepa.model.Hiding;
import uk.ac.ed.inf.pepa.model.Prefix;
import uk.ac.ed.inf.pepa.model.Process;
import umontreal.iro.lecuyer.simevents.Event;
import umontreal.iro.lecuyer.simevents.Sim;
import umontreal.iro.lecuyer.stat.Tally;
import umontreal.iro.lecuyer.util.Chrono;

/**
 * Create a discrete-time event-based simulation model for a PEPA description.
 * 
 * @author mtribast
 * 
 */
public final class SimulationModel {

	final HashMap<Integer, Component> components = new HashMap<Integer, Component>();

	final Process systemEquation;

	final EventBuilder builder;

	/**
	 * This object is responsible for passage time analysis
	 */
	final PassageTimeObserver passageTime;

	/**
	 * This object is responsible for action throughput
	 */
	final ActionThroughputObserver actionThroughput;
	
	final SynchronisedActionDurationObserver actionDuration;
	
	private HashMap<Action, Tally> throughputData;
	
	/**
	 * Create a simulation model from a <b>fully expanded</b> (i.e., leaves
	 * must be sequential components) system equation.
	 * 
	 * @param systemEquation
	 */
	public SimulationModel(Process systemEquation) {

		this.systemEquation = systemEquation;

		systemEquation.accept(new LabelingVisitor() {

			@Override
			public void doVisitChoice(Choice choice) {
				throw new IllegalStateException(
						"Shouldn't find any choice here");
			}

			@Override
			public void doVisitConstant(Constant constant) {
				add(constant);
			}

			@Override
			public void doVisitCooperation(Cooperation cooperation) {
				// cooperationLabels.put(cooperation, label);
				// System.err.println("Label for " + cooperation.prettyPrint()
				// + " : " + label);
				cooperation.getLeftHandSide().accept(this);
				cooperation.getRightHandSide().accept(this);
			}

			@Override
			public void doVisitHiding(Hiding hiding) {
				add(hiding);
			}

			@Override
			public void doVisitPrefix(Prefix prefix) {
				add(prefix);
			}

			private void add(Process process) {
				if (null != components
						.put(label, new Component(label, process)))
					throw new IllegalStateException("Couldn't add component "
							+ process.prettyPrint());
				// else
				// TODO Remove this is for debug only
				// System.err.println("Added " + process.prettyPrint()
				// + " position " + label);
			}

		});

		this.builder = new EventBuilder(this);
		passageTime = new PassageTimeObserver("a", "b");
		actionThroughput = new ActionThroughputObserver();
		actionDuration = new SynchronisedActionDurationObserver();

	}

	public void lazyInit() {
		passageTime.lazyInit();
		
		actionThroughput.lazyInit();
		
		// resets generators to next substreams
		TableEntry.mng.lazyInit();
		
		for (Component c : components.values())
			c.lazyInit();
	}

	public void debug() {
		builder.doWork();
	}

	/**
	 * Simulate the model over the given number of runs for
	 * <code>timeHorizon</code> simulation time.
	 * 
	 * @param numberOfRuns
	 *            total number of indipendent runs
	 * @param timeHorizon
	 *            simulation time for each run
	 */
	public void simulate(int numberOfRuns, double timeHorizon) {
		Chrono chrono = Chrono.createForSingleThread();

		throughputData = new HashMap<Action, Tally>();
		
		//durationData = new HashMap<Action, Tally>();

		for (int i = 0; i < numberOfRuns; i++) {
			System.out.println("Run # " + (i + 1));

			/* Lazy initialisation of components */
			if (i != 0) {
				lazyInit();
			}

			/* Simulation of the model */
			simulateOneRun(timeHorizon);

			/* Update utilisation information */
			for (Component c : components.values()) {
				c.newRun();
			}
			
			/* Update throughput */
			updateThroughput();
			
			/* Update action duration */
			//updateActionDuration();
	
		}

		/* Execution time information */
		System.out.println("Completed\nTotal CPU time: " + chrono.format());
		double secs = chrono.getSeconds();
		double avg = secs / numberOfRuns;
		System.out.println("Average time per run: " + avg + " s");
		System.out.println("Average ratio per run: " + timeHorizon / avg);

		showUtilisationFigures(timeHorizon);
		
		showThroughputFigures(timeHorizon);
		
		showSynchronisedActionsFigures();
		
		
		passageTime.debug();

	}
	
	private void simulateOneRun(double timeHorizon) {
		// initialise simulation
		Sim.init();
		// stop event
		new Event() {
			public void actions() {
				Sim.stop();
			}
		}.schedule(timeHorizon);
		builder.doWork(); // create first set of events
		/* other doWork()'s will be called by events' actions() */
		Sim.start();
	
	}

	private void updateThroughput() {
		/* Number of executions */
		for (java.util.Map.Entry<Action, Integer> entry : actionThroughput.th
				.entrySet()) {
			Tally tally = throughputData.get(entry.getKey());
			if (tally == null) {
				tally = new Tally("Throughput of " + entry.getKey().prettyPrint());
				throughputData.put(entry.getKey(), tally);
			}
			tally.add(entry.getValue());
		}
	}
	
	/*private void updateActionDuration() {
		 Number of executions 
		for (java.util.Map.Entry<Action, Tally> entry : actionDuration.duration
				.entrySet()) {
			Tally tally = durationData.get(entry.getKey());
			if (tally == null) {
				tally = new Tally("Average duration of " + entry.getKey().prettyPrint());
				durationData.put(entry.getKey(), tally);
			}
			tally.add(entry.getValue().average());
		}
	}
	*/
	private void showUtilisationFigures(double timeHorizon) {
		System.out.println("\nUtilisation");
		System.out.println("***********");
		/* Print out utilisation information */
		for (Component c : components.values()) {
			System.out.println("o Component:" + c.position);
			for (java.util.Map.Entry<Process, Tally> entry : c.getTallies()
					.entrySet()) {
				System.out.println("\t- Local state: "
						+ entry.getKey().prettyPrint());
				System.out.println("\t\tAverage: " + entry.getValue().average()
						/ timeHorizon + "%");
				System.out.println("\t\tStd: "
						+ entry.getValue().standardDeviation() / timeHorizon);
			}
		}
	}
	
	private void showThroughputFigures(double timeHorizon) {
		System.out.println("\nThroughput");
		System.out.println("**********");
		/* Print out throughput information */
		for (java.util.Map.Entry<Action, Tally> entry : throughputData
				.entrySet()) {
			System.out.println("o Action: " + entry.getKey().prettyPrint());
			System.out
					.println("\t- Average: " + entry.getValue().average() / timeHorizon);
			double absStd = entry.getValue().standardDeviation();
			System.out.println("\t- Std: " + absStd / timeHorizon + " [" + absStd
					/ entry.getValue().average() * 100d + "%]");
		}
	}
	
	private void showSynchronisedActionsFigures() {
		System.out.println("\nSynchronised Activities");
		System.out.println("************************");
		/* Print out duration information */
		for (java.util.Map.Entry<Action, Tally> entry : actionDuration.duration
				.entrySet()) {
			System.out.println("o Action: " + entry.getKey().prettyPrint());
			System.out
					.println("\t- Average: " + entry.getValue().average());
			double absStd = entry.getValue().standardDeviation();
			System.out.println("\t- Std: " + absStd + " [" + absStd
					/ entry.getValue().average() * 100d + "%]");
		}
	}

	// TODO Remove this, only for debugging, it may slow down a lot!
	private static final boolean DO_LOG = true;

	public static void log(String s) {
		if (DO_LOG)
			System.err.println(s);
	}
}