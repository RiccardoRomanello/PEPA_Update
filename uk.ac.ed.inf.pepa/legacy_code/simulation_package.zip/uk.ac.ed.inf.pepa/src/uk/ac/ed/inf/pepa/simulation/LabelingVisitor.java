package uk.ac.ed.inf.pepa.simulation;

import uk.ac.ed.inf.pepa.model.Aggregation;
import uk.ac.ed.inf.pepa.model.Choice;
import uk.ac.ed.inf.pepa.model.Constant;
import uk.ac.ed.inf.pepa.model.Cooperation;
import uk.ac.ed.inf.pepa.model.Hiding;
import uk.ac.ed.inf.pepa.model.Prefix;
import uk.ac.ed.inf.pepa.model.Visitor;

public class LabelingVisitor implements Visitor {

	public void visitAggregation(Aggregation aggregation) {
		// TODO Auto-generated method stub

	}

	public void visitChoice(Choice choice) {
		// TODO Auto-generated method stub

	}

	public void visitConstant(Constant constant) {
		// TODO Auto-generated method stub

	}

	public void visitCooperation(Cooperation cooperation) {
		// TODO Auto-generated method stub

	}

	public void visitHiding(Hiding hiding) {
		// TODO Auto-generated method stub

	}

	public void visitPrefix(Prefix prefix) {
		// TODO Auto-generated method stub

	}

}
