package uk.ac.ed.inf.pepa.simulation;

import java.util.HashMap;

import uk.ac.ed.inf.pepa.model.Action;
import umontreal.iro.lecuyer.stat.Tally;

public class SynchronisedActionDurationObserver {
	
	HashMap<Action, Tally> duration;
	
	public SynchronisedActionDurationObserver() {
		duration = new HashMap<Action, Tally>(); //lazyInit();
	}
	
	public void synchronisedActionToBePerformed(Action action,
			double delay) {
		Tally t = duration.get(action);
		if (t == null) {
			t = new Tally("Duration of " + action.prettyPrint());
			duration.put(action, t);
		}
		t.add(delay);
	}
}
