package uk.ac.ed.inf.pepa.simulation;

import java.util.HashMap;
import java.util.Map;

import uk.ac.ed.inf.pepa.model.Action;
import uk.ac.ed.inf.pepa.model.Process;
import umontreal.iro.lecuyer.simevents.Sim;
import umontreal.iro.lecuyer.stat.Tally;

public final class Component {
	
	/**
	 * Unique number specifing the position in the system equation's binary tree
	 */
	final int position;
	
	/**
	 * Current local state of the component
	 */
	Process state;

	/**
	 * True if the component has engaged in some action. By default, it is not
	 * enabled
	 */
	boolean enabled;

	/**
	 * Caches the original state so that there is no need for
	 * creating the component when a new simulation run is 
	 * launched.
	 */
	private final Process firstState;
	
	/**
	 * Utilisation manager for this component
	 */
	final private UtilisationManager umng;
	
	/**
	 * Throughput manager for this component
	 */
	//final private ThroughputManager tmng; 

	Component(int position, Process state) {
		umng = new UtilisationManager();
		//tmng = new ThroughputManager();
		this.position = position;
		this.state = state;
		this.enabled = false;
		this.firstState = state;
	}
	
	public void lazyInit() {
		umng.lazyInit();
		//tmng.lazyInit();
		this.enabled = false;
		this.state = firstState;
		
	}
	
	public void newRun() {
		umng.newRun();
	}

	/**
	 * Set the new state of this component.
	 * <p>
	 * This is usually called during simulation.
	 * 
	 * @param action
	 *            which action is going to keep this component busy
	 * @param delay
	 *            how long this component is going to be in this state
	 */
	public void addDelay(Action action, double delay) {
		umng.addDelay(state, delay);
		//tmng.addExecution(action, delay);
	}
	
	/**
	 * Throughput information for this component. It is a map
	 * which associates an action to the total amount of time
	 * this component has spent performing that action.
	 * @return
	 */
	/*public Map<Action, Double> getThroughput() {
		return tmng.th;
	}*/
	
	/**
	 * Uitilisation information for this components. It is a map
	 * which associates a local state to the total amount of time
	 * this component has been in this state. This information
	 * is usually normalised with respect to the simulatio time.
	 * 
	 * @return
	 */
	public Map<Process, Double> getUtilisation() {
		return umng.utilisation;
	}
	
	public Map<Process, Tally> getTallies() {
		return umng.tallies;
	}

	public void debug(double totalTime) {
		System.out.println("Component " + position + "\n***");
		umng.debug(totalTime);
		//tmng.debug(totalTime);
	}

}

final class ThroughputManager {

	final HashMap<Action, Double> th;

	
	public ThroughputManager() {
		th = new HashMap<Action, Double>();
		lazyInit();
	}
	
	public void lazyInit() {
		for (Action action : th.keySet()) {
			th.put(action, 0.0d);
		}
	}
	
	public void addExecution(Action action, double delay) {
		Double old = th.get(action);
		if (old == null)
			old = 0d;
		old += delay;
		th.put(action, old);
	}

	public void debug(double totalTime) {
		System.out.println("Throughput");
		for (java.util.Map.Entry<Action, Double> entry : th
				.entrySet()) {
			System.out.println("\t" + entry.getKey().prettyPrint() + " : "
					+ (entry.getValue() / totalTime));
		}
	}

}

final class UtilisationManager {
	
	/**
	 * Contains utilisation information for the entire simulation.
	 * <p>
	 * The tallies are updated when {@link #newRun()} is called
	 */
	final HashMap<Process, Tally> tallies;
	
	/**
	 * Contains utilisation information for a single run.
	 * <p>
	 * Upon {@link #newRun()}, this information is processed
	 * and the corresponding tally is updated. 
	 */
	final HashMap<Process, Double> utilisation;

	/**
	 * Simulation time since a change in this component was last seen
	 */
	private double lastSeen;

	/**
	 * Total time this component is spending waiting for other components to
	 * finish their transitions in order to synchronise with them.
	 * 
	 * <pre>
	 *  P1 = (a, T).P2;
	 *  P2 = (c, 1).P1;
	 *  
	 *  Q1 = (a, 1).Q2;
	 *  Q2 = (d, 1).Q1;
	 *  
	 *  
	 *  P2      P1
	 *  --------|&circ;&circ;&circ;&circ;&circ;&circ;&circ;&circ; 
	 *     c
	 *  
	 *  
	 *  Q2              Q1            
	 *  ----------------|
	 *         d
	 *  
	 *  -- = transition in progress
	 *  &circ;&circ; = waiting time
	 * </pre>
	 */
	private double waitingTime;
	
	public UtilisationManager() {
		utilisation = new HashMap<Process, Double>();
		tallies = new HashMap<Process, Tally>();
		
		lazyInit();
	}
	
	public void lazyInit() {
		lastSeen = 0.0d;
		waitingTime = 0.0d;
		for (Process p : utilisation.keySet()) {
			utilisation.put(p, 0.0d);
		}
	}
	
	public void addDelay(Process process, double delay) {
		double currentTime = Sim.time();
		Double old = utilisation.get(process);
		if (old == null)
			old = 0d;
		double thisWaitingTime = currentTime - lastSeen;
		waitingTime += thisWaitingTime;
		old += thisWaitingTime + delay;
		lastSeen = currentTime + delay;
		utilisation.put(process, old);

	}
	
	public void newRun() {
		for (java.util.Map.Entry<Process, Double> entry : utilisation.entrySet()) {
			Tally tally = tallies.get(entry.getKey());
			if (tally == null) {
				tally = new Tally("Total time spent in state " + entry.getKey().prettyPrint());
				tallies.put(entry.getKey(), tally);
			}
			tally.add(entry.getValue());
		}
	}

	public void debug(double totalTime) {
		System.out.println("Utilisation [" + waitingTime / totalTime
				+ " waiting]");
		for (java.util.Map.Entry<Process, Double> entry : utilisation
				.entrySet()) {
			System.out.println("\t" + entry.getKey().prettyPrint() + " : "
					+ (entry.getValue() / totalTime));
		}
	}
}
