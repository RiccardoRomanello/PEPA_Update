package uk.ac.ed.inf.pepa.simulation;

import java.util.ArrayList;

import uk.ac.ed.inf.pepa.model.Aggregation;
import uk.ac.ed.inf.pepa.model.Choice;
import uk.ac.ed.inf.pepa.model.Constant;
import uk.ac.ed.inf.pepa.model.Cooperation;
import uk.ac.ed.inf.pepa.model.Hiding;
import uk.ac.ed.inf.pepa.model.Prefix;
import uk.ac.ed.inf.pepa.model.Visitor;

public final class LabelledVisitor {
	
	Component component;
	
	ArrayList<TableEntry> entries = new ArrayList<TableEntry>();
	
	/**
	 * Create a visitor that produces entries for this
	 * label
	 * @param label
	 */
	LabelledVisitor(Component component) {
		this.component = component;
		
		component.state.accept(new Visitor() {
			public void visitAggregation(Aggregation aggregation) {
				throw new IllegalStateException("Aggregation not supported yet");
			}

			public void visitChoice(Choice choice) {
				choice.getLeftHandSide().accept(this);
				choice.getRightHandSide().accept(this);
			}

			public void visitConstant(Constant constant) {
				constant.getBinding().accept(this);
			}

			public void visitCooperation(Cooperation cooperation) {
				throw new IllegalStateException("Should never be called here");
			}

			public void visitHiding(Hiding hiding) {
				throw new IllegalStateException("Hiding not implemented yet");
			}

			public void visitPrefix(Prefix prefix) {
				TableEntry entry = new TableEntry(prefix.getActivity().getAction(),
						prefix.getActivity().getRate(), LabelledVisitor.this.component, prefix.getTargetProcess());
				entries.add(entry);
			}

		});
	}
	
	
}
