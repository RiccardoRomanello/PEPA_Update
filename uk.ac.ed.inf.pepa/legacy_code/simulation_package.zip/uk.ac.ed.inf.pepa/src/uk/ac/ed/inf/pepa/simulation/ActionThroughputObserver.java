package uk.ac.ed.inf.pepa.simulation;

import java.util.HashMap;

import uk.ac.ed.inf.pepa.model.Action;

/**
 * Counts how many times an action is fired during a simulation
 * run.
 * 
 * @author mtribast
 *
 */
public final class ActionThroughputObserver {
	
	/**
	 * This map associates an action to the number of times 
	 * it is performed
	 */
	final HashMap<Action, Integer> th;
	
	ActionThroughputObserver() {
		th = new HashMap<Action, Integer>();
	}
	
	/**
	 * This is a re-usable object. The lazy initialisator
	 * simply clears the number of events for each action
	 *
	 */
	public void lazyInit() {
		for (Action a : th.keySet()) {
			th.put(a, 0);
		}
	}
	
	public void actionToBePerformed(Action action, int numberOfComponents) {
		Integer old = th.get(action);
		if (old == null) {
			old = 0;
		}
		//old += numberOfComponents;
		old += 1;
		th.put(action, old);
	}
}
