package uk.ac.ed.inf.pepa.simulation;

import uk.ac.ed.inf.pepa.model.Action;
import umontreal.iro.lecuyer.simevents.Sim;
import umontreal.iro.lecuyer.stat.Tally;

public class PassageTimeObserver {

	private final String start;

	private final String stop;

	private double startTime;

	Tally passageTime;
	
	public PassageTimeObserver(String startAction, String stopAction) {
		this.start = startAction;
		this.stop = stopAction;
		lazyInit();
	}
	
	public void lazyInit() {
		startTime = Double.NaN;
		/* Isn't there any lazy initialisator for this object? */
		passageTime = new Tally("Passage time");
		
	}
	public void activityToBePerformed(Action action) {
		if (action.prettyPrint().equals(start)) {
			if (Double.isNaN(startTime))
				startTime = Sim.time();
			return;
		}
	}

	public void activityConcluded(Action action) {
		if (action.prettyPrint().equals(stop)) {
			/* Update passage time */
			if (!Double.isNaN(startTime)) {
				// System.err.println("Stop");
				passageTime.add(Sim.time() - startTime);
				startTime = Double.NaN;
			}
		}
	}

	public void debug() {
		System.out.println("Passage time mean: " + passageTime.average());
		System.out.println("Passage time std: "
				+ passageTime.standardDeviation());
		System.out.println("Passage time obs: " + passageTime.numberObs());

	}

}
