package uk.ac.ed.inf.pepa.simulation;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public final class EventBuilder {
	
	/** Reusable instance of the comparator for table entries */
	private static final Comparator<TableEntry> COMPARATOR = new Comparator<TableEntry>() {
		
		public int compare(TableEntry arg0, TableEntry arg1) {
			
			if (arg0.computeDelay() == arg1.computeDelay()) {
				return arg0.component.position - arg1.component.position;
			}
			if (arg0.computeDelay() < arg1.computeDelay())
				return -1;
			return 1;
		}
	};
	
	SimulationModel model;

	private List<TableEntry> entries;

	EventBuilder(SimulationModel model) {

		this.model = model;
	}

	public void doWork() {

		TableEntryProvider v = new TableEntryProvider(0, model);

		model.systemEquation.accept(v);

		entries = v.getEntries();

		/*
		 * Select related synchronised activities and update delay
		 */
		new_algorithm();

		/*
		 * Sort in ascending delay order
		 */
		sort();

		/*
		 * Debug
		 */
		// print_entries(entries);
		/* Now enable no more than one transition per component */
		findEvents();

	}

	/*
	 * private void print_entries(List<TableEntry> pEntries) { for (TableEntry
	 * entry : pEntries) { SimulationModel.log("***");
	 * SimulationModel.log(entry.toString()); } }
	 */

	private void new_algorithm() {
		/*
		 * Select related synchronised activities and update delays. At the end,
		 * no infinite delay should be seen
		 */
		List<TableEntry> visited = new ArrayList<TableEntry>();
		List<TableEntry> removable = new ArrayList<TableEntry>();
		for (TableEntry entry : entries) {
			if (!visited.contains(entry) && !removable.contains(entry)) {
				if (entry.synchronisation != null) {
					/* Needs synchronisation */
					List<TableEntry> visitedElements = null;
					try {
						visitedElements = updateSynchronisingElements(entry);
						visited.addAll(visitedElements);
					} catch (ToBeRemovedException e) {
						removable.addAll(e.entries);
					}
				}
			}
		}
		entries.removeAll(removable);
	}

	private void sort() {
		/* TODO Possible Performance Hot Spot */
		Collections.sort(entries, COMPARATOR);
	}

	private List<TableEntry> updateSynchronisingElements(TableEntry entry)
			throws ToBeRemovedException {
		// TODO for performance, clear rather than create from scratch
		// List<TableEntry> sync = new ArrayList<TableEntry>();
		double max = Double.NEGATIVE_INFINITY;

		boolean atLeastOneEnabled = false;

		// SimulationModel.log("^^^\nEntry\n" + entry + "\n^^^");
		List<TableEntry> visited = new ArrayList<TableEntry>();
		/* First pass, compute the maximum */
		for (TableEntry other : entries) {
			if (entry.synchronisation == other.synchronisation) {
				visited.add(other);
				if (other.component.enabled)
					atLeastOneEnabled = true;
				if (!Double.isInfinite(other.computeDelay()))
					max = Math.max(max, other.computeDelay());
			}
		}

		/* Second pass, set it */

		if (Double.isInfinite(max) || visited.size() == 1 || atLeastOneEnabled) {
			/*
			 * Transition not possible, either no partner or no active
			 * transition
			 */
			throw new ToBeRemovedException(visited);

		}
		// SimulationModel.log("^^^Max : " + max);
		for (TableEntry visitedEntry : visited) {
			visitedEntry.setDelay(max);
		}

		return visited;

	}

	private void findEvents() {

		//System.err.println("Find Events called");

		//Thread.dumpStack();

		List<TableEntry> visited = new ArrayList<TableEntry>();
		
		//List<TableEntry> companions = new ArrayList<TableEntry>();
		
		for (int i = 0; i < entries.size(); i++) {
			TableEntry current = entries.get(i);
			if (visited.contains(current))
				continue; // next
			if (current.synchronisation == null) {
				if (!current.component.enabled)
					createEvent(new TableEntry[] { current });
					//new IndependentEvent(current,this).schedule(current.computeDelay());

			} else {
				/*
				 * Look for synchronising activities
				 * 
				 * Synchronised entries are always below this, because of the
				 * ordering of the table
				 */

				List<TableEntry> companions = new ArrayList<TableEntry>();
				//companions.clear();
				boolean isOneEnabled = false;
				for (int j = i; j < entries.size(); j++) {
					TableEntry companion = entries.get(j);
					if (companion.synchronisation == current.synchronisation) {
						companions.add(companion);
						if (companion.component.enabled)
							isOneEnabled = true;
					}
				}
				visited.addAll(companions);
				if (!isOneEnabled) {

					// print_entries(companions);

					createEvent(companions.toArray(new TableEntry[companions
							.size()]));
				}

			}
		}

	}

	/**
	 * Create the event and schedule it
	 * 
	 * @param entries
	 */
	private void createEvent(TableEntry[] eventEntries) {
		// System.out.println(eventEntries.length);
		// for (TableEntry entry : eventEntries) {
		// System.out.println("Entry: " + entry);
		// }
		new ActivityCompleted(eventEntries, this).schedule(eventEntries[0]
				.computeDelay());
	}

}

class ToBeRemovedException extends Exception {

	List<TableEntry> entries;

	ToBeRemovedException(List<TableEntry> entries) {

		this.entries = entries;

	}
}
