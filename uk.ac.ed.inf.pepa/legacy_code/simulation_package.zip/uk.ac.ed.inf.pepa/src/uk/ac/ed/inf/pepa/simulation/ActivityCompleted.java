package uk.ac.ed.inf.pepa.simulation;

import java.util.Map;

import umontreal.iro.lecuyer.simevents.Event;
import umontreal.iro.lecuyer.simevents.Sim;

/**
 * Represents an event for the SSJ framework.
 * 
 * @author mtribast
 * 
 */
public class ActivityCompleted extends Event {

	private TableEntry[] entries;

	private EventBuilder builder;

	private static final boolean LOG = false;

	/*
	 * public static final PassageTimeManager mng = new PassageTimeManager();
	 */

	/**
	 * Create a new event which changes the state of the given model according
	 * to the information in the given entries.
	 * 
	 * @param entries
	 */
	ActivityCompleted(TableEntry[] entries, EventBuilder builder) {
		this.entries = entries;
		this.builder = builder;

		print_current_status("New Event at " + Sim.time());

		print_entries(true);

		enableComponents();

	}

	private void print_current_status(String message) {
		if (!LOG)
			return;
		System.out.println("############## " + message + "\n");

		System.out.println("- Current state");
		for (Map.Entry<Integer, Component> entry : this.builder.model.components
				.entrySet()) {
			System.out.println("\t" + entry.getValue().state.prettyPrint()
					+ ", " + entry.getValue().position + ", "
					+ entry.getValue().enabled);
		}
	}

	private void print_entries(boolean printTime) {
		if (!LOG)
			return;
		System.out.println("- Entries");
		for (TableEntry entry : entries) {
			System.out.println("\t"
					+ entry.component.state.prettyPrint()
					+ " -> "
					+ entry.process.prettyPrint()
					+ ", action: "
					+ entry.action.prettyPrint()
					+ ((printTime) ? ", t: "
							+ (entry.computeDelay() + Sim.time()) : ""));
		}
	}

	private void enableComponents() {
		for (TableEntry entry : entries) {
			entry.component.enabled = true;
			// register statistics on the previous state of this component
			entry.component.addDelay(entry.action, entry.computeDelay());
		}

		/* It's the same for all!!! */
		this.builder.model.passageTime.activityToBePerformed(entries[0].action);
		this.builder.model.actionThroughput.actionToBePerformed(
				entries[0].action, entries.length);
		if (entries.length > 1)
			this.builder.model.actionDuration.synchronisedActionToBePerformed(
					entries[0].action, entries[0].computeDelay());
	}

	@Override
	/**
	 * Change the state of the components in this entry and schedules new events
	 */
	public void actions() {

		print_current_status("Event picked at " + Sim.time());

		print_entries(false);

		for (TableEntry entry : entries) {

			entry.component.enabled = false;
			entry.component.state = entry.process;
		}

		/* It's the same for all!!! */
		this.builder.model.passageTime.activityConcluded(entries[0].action);

		// this will schedule new events
		builder.doWork();
	}

}