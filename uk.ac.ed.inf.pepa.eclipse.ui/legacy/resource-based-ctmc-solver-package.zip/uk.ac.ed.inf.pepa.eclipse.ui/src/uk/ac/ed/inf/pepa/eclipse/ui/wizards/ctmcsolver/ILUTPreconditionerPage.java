package uk.ac.ed.inf.pepa.eclipse.ui.wizards.ctmcsolver;

import java.util.Map;

import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Label;

import uk.ac.ed.inf.pepa.ctmc.solution.OptionMap;
import uk.ac.ed.inf.pepa.eclipse.ui.wizards.WizardMessages;
import uk.ac.ed.inf.pepa.eclipse.ui.wizards.ctmcsolver.AbstractConfigurationWizardPage.DoubleConfigurationText;
import uk.ac.ed.inf.pepa.eclipse.ui.wizards.ctmcsolver.AbstractConfigurationWizardPage.IntegerConfigurationText;

public class ILUTPreconditionerPage extends AbstractConfigurationSolverPage {

	private DoubleConfigurationText tau;
	private IntegerConfigurationText p;

	protected ILUTPreconditionerPage() {
		super("ILUT");
		setTitle(WizardMessages.ILUT_TITLE);
		setDescription(WizardMessages.ILUT_DESCRIPTION);
	}

	public Map getOptions() {
		Map options = super.getOptions();
		options.put(OptionMap.PRECONDITIONER, OptionMap.ILUT);
		return options;
	}


	@Override
	protected void fillSettingPanel() {
		Label tauLabel = new Label(this.settingPanel, labelStyle);
		tauLabel
				.setText("Drop tolerance");
		tau.createControl(settingPanel);
		
		Label pLabel = new Label(this.settingPanel, labelStyle);
		pLabel
				.setText("Number of entries to keep on each row");
		p.createControl(settingPanel);
		this.configurationWidgets.add(p);
		
		int horizontal = GridData.FILL_HORIZONTAL | GridData.GRAB_HORIZONTAL;

		tauLabel.setLayoutData(new GridData());
		tau.control.setLayoutData(new GridData(horizontal));
		pLabel.setLayoutData(new GridData());
		p.control.setLayoutData(new GridData(horizontal));
		
	}

	@Override
	public boolean isNeedPage() {
		return true;
	}

	@Override
	protected void createConfigurationWidgets() {
		tau = new DoubleConfigurationText(
				OptionMap.ILUT_TAU);
		this.configurationWidgets.add(tau);

		p = new IntegerConfigurationText(
				OptionMap.ILUT_P);
		this.configurationWidgets.add(p);

		
	}

}
