package uk.ac.ed.inf.pepa.eclipse.ui.wizards.ctmcsolver;

import java.util.Map;

import uk.ac.ed.inf.pepa.ctmc.solution.OptionMap;

public class PreconditionerPageFactory {

	/**
	 * Factory for MTJ preconditioner
	 * 
	 * @param id
	 *            preconditioner unique identifier
	 * @return the preconditioner setting page, or null if none is available
	 */
	public static ISolverPage createPreconditionerPageFor(int id) {
		// TODO Complete this list
		switch (id) {
		case OptionMap.AMG:
			return new AMGPreconditionerPage();
		case OptionMap.SSOR:
			return new SSORPreconditioner();
		case OptionMap.DIAGONAL:
			return new AbstractConfigurationSolverPage("") {
				
				@Override
				protected void fillSettingPanel() {
				}

				public Map getOptions() {
					Map options = super.getOptions();
					options.put(OptionMap.PRECONDITIONER, OptionMap.DIAGONAL);
					return options;
				}

				@Override
				public boolean isNeedPage() {
					return false;
				}

				@Override
				protected void createConfigurationWidgets() {
				}

			};
		case OptionMap.NO_PRECONDITIONER:
			return new AbstractConfigurationSolverPage("") {

				public Map getOptions() {
					Map options = super.getOptions();
					options.put(OptionMap.PRECONDITIONER,
							OptionMap.NO_PRECONDITIONER);
					return options;
				}

				@Override
				protected void fillSettingPanel() {
					// TODO Auto-generated method stub

				}

				@Override
				public boolean isNeedPage() {
					return false;
				}

				@Override
				protected void createConfigurationWidgets() {
				}

			};
		case OptionMap.ICC:
			return new AbstractConfigurationSolverPage("") {

				
				public Map getOptions() {
					Map options = super.getOptions();
					options.put(OptionMap.PRECONDITIONER, OptionMap.ICC);
					return options;
				}

				@Override
				protected void fillSettingPanel() {
				}

				@Override
				public boolean isNeedPage() {
					return false;
				}

				@Override
				protected void createConfigurationWidgets() {
				}

			};
		case OptionMap.ILU:
			return new AbstractConfigurationSolverPage("") {

				public Map getOptions() {
					Map options = super.getOptions();
					options.put(OptionMap.PRECONDITIONER, OptionMap.ILU);
					return options;
				}

				@Override
				protected void fillSettingPanel() {
					// TODO Auto-generated method stub

				}

				@Override
				public boolean isNeedPage() {
					return false;
				}

				@Override
				protected void createConfigurationWidgets() {
				}

			};
		case OptionMap.ILUT:
			return new ILUTPreconditionerPage();

		}
		return null;
	}

}
