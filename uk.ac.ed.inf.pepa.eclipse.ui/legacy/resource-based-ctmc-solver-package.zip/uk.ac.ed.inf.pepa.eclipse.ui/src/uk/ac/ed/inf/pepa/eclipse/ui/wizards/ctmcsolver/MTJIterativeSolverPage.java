package uk.ac.ed.inf.pepa.eclipse.ui.wizards.ctmcsolver;

import java.util.Collection;
import java.util.Map;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.jface.wizard.IWizardPage;
import org.eclipse.jface.wizard.Wizard;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Listener;

import uk.ac.ed.inf.pepa.ctmc.solution.OptionMap;
import uk.ac.ed.inf.pepa.eclipse.core.PepaCore;
import uk.ac.ed.inf.pepa.eclipse.core.PepatoOptionForwarder;
import uk.ac.ed.inf.pepa.eclipse.ui.wizards.IResourceProvider;
import uk.ac.ed.inf.pepa.eclipse.ui.wizards.WizardMessages;

public class MTJIterativeSolverPage extends AbstractConfigurationSolverPage {

	private String currentSelectedPreconditioner = null;

	private Combo comboPreconditioners;

	private int precondId;

	private ISolverPage nextPage = null;

	private IntegerConfigurationText maxIterText;

	private DoubleConfigurationText rTolText;

	private DoubleConfigurationText aTolText;

	private DoubleConfigurationText dTolText;

	protected MTJIterativeSolverPage(int id) {
		super("MTJIterativeSolverPage");
		setTitle(WizardMessages.MTJ_ITERATION_TITLE);
		setDescription("Set solver parameters");
		precondId = id;
	}

	protected void fillSettingPanel() {

		Label iterLabel = new Label(settingPanel, labelStyle);
		iterLabel.setText("");
		GridData iterData = new GridData();
		iterData.horizontalSpan = 2;
		iterLabel.setLayoutData(iterData);

		Label labelMaxIter = new Label(settingPanel, labelStyle);
		labelMaxIter.setText("Maximum number of iterations");
		maxIterText.createControl(settingPanel);

		Label labelRTol = new Label(settingPanel, labelStyle);
		labelRTol.setText("Relative tolerance");
		rTolText.createControl(settingPanel);

		Label labelATol = new Label(settingPanel, labelStyle);
		labelATol.setText("Absolute tolerance");
		aTolText.createControl(settingPanel);

		Label labelDTol = new Label(settingPanel, labelStyle);
		labelDTol.setText("Divergence tolerance");
		dTolText.createControl(settingPanel);

		labelMaxIter.setLayoutData(new GridData());
		
		maxIterText.control.setLayoutData(new GridData(gridDataStyle));
		labelRTol.setLayoutData(new GridData());
		rTolText.control.setLayoutData(new GridData(gridDataStyle));
		labelATol.setLayoutData(new GridData());
		aTolText.control.setLayoutData(new GridData(gridDataStyle));
		labelDTol.setLayoutData(new GridData());
		dTolText.control.setLayoutData(new GridData(gridDataStyle));

		Label precondLabel = new Label(settingPanel, SWT.NONE);
		precondLabel.setText("Select the preconditioner");
		// GridData precondData = new GridData();
		// precondData.horizontalSpan = 2;
		// precondLabel.setLayoutData(precondData);
		precondLabel.setLayoutData(new GridData());

		comboPreconditioners = new Combo(settingPanel, SWT.READ_ONLY);
		GridData comboData = new GridData();
		// comboData.horizontalSpan = 2;
		// comboPreconditioners.setLayoutData(comboData);
		populatePreconditionerCombo();
		comboPreconditioners.setLayoutData(new GridData(gridDataStyle));

		initSettings();

	}

	public final IWizardPage getNextPage() {
		if (this.nextPage != null && this.nextPage.isNeedPage())
			return nextPage;
		else
			return null;
	}

	public Map getOptions() {
		Map options = super.getOptions();
		options.put(OptionMap.SOLVER, precondId);
		if (nextPage != null)
			options.putAll(nextPage.getOptions());
		return options;
	}

	protected void initSettings() {

		/* Setting for non configuration widgets */
		String option = null;
		try {
			option = PepatoOptionForwarder.getOptionFromPersistentResource(
					((IResourceProvider) getWizard()).getResource(),
					OptionMap.PRECONDITIONER);
		} catch (CoreException e) {
			// o stays null
		}

		if (option == null) {
			setDefaultPreconditioner();
		} else {
			int preconditioner = Integer.parseInt(option);
			setPreconditioner(preconditioner);
		}

	}

	protected void resetToDefaults() {
		super.resetToDefaults();
		setDefaultPreconditioner();
	}

	private void setDefaultPreconditioner() {
		setPreconditioner(PepaCore.getDefault().getPluginPreferences()
				.getDefaultInt(OptionMap.PRECONDITIONER));
	}

	private void setPreconditioner(int id) {
		comboPreconditioners.setText(Preconditioners.getInstance()
				.getPreconditionerName(id));
		newPreconditionerSelected(comboPreconditioners.getText());
	}

	private void newPreconditionerSelected(String textPreconditioner) {
		setPageComplete(false);

		ISolverPage preconditionerPage = PreconditionerPageFactory
				.createPreconditionerPageFor(Preconditioners.getInstance()
						.getPreconditionerId(textPreconditioner));

		if (preconditionerPage == null) {
			/* An unexpected error occurred */
			setMessage(null);
			String error = "No Preconditioner available";
			setErrorMessage(error);
			this.nextPage = null;
			return;
		}

		if (this.nextPage != null
				&& textPreconditioner.equals(currentSelectedPreconditioner)) {
			// do nothing
		} else {

			this.nextPage = preconditionerPage;
			if (preconditionerPage.isNeedPage()) {
				((Wizard) getWizard()).addPage(nextPage);
			}

		}
		this.currentSelectedPreconditioner = textPreconditioner;
		setMessage(null);
		setErrorMessage(null);
		setPageComplete(true);

	}

	private void populatePreconditionerCombo() {

		Collection<String> precondStrings = Preconditioners.getInstance()
				.getAvailablePreconditioners();

		for (String element : precondStrings)
			comboPreconditioners.add(element);

		comboPreconditioners.addListener(SWT.Selection, new Listener() {
			public void handleEvent(Event event) {
				newPreconditionerSelected(comboPreconditioners.getText());
			}
		});
	}

	/*
	 * Return true because there's implementation for parameter setting.
	 */
	public boolean isNeedPage() {
		return true;
	}

	@Override
	protected void createConfigurationWidgets() {
		maxIterText = new IntegerConfigurationText(
				OptionMap.ITER_MON_MAX_ITER);

		rTolText = new DoubleConfigurationText(
				OptionMap.ITER_MON_RTOL);

		aTolText = new DoubleConfigurationText(
				OptionMap.ITER_MON_ATOL);

		dTolText = new DoubleConfigurationText(
				OptionMap.ITER_MON_DTOL);
		this.configurationWidgets.add(maxIterText);
		this.configurationWidgets.add(rTolText);
		this.configurationWidgets.add(aTolText);
		this.configurationWidgets.add(dTolText);
		
	}

}
