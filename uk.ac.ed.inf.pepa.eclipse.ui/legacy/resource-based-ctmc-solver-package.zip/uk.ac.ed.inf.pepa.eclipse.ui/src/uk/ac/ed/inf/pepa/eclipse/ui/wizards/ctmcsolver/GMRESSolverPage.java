package uk.ac.ed.inf.pepa.eclipse.ui.wizards.ctmcsolver;

import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Label;

import uk.ac.ed.inf.pepa.ctmc.solution.OptionMap;
import uk.ac.ed.inf.pepa.eclipse.ui.wizards.WizardMessages;
import uk.ac.ed.inf.pepa.eclipse.ui.wizards.ctmcsolver.AbstractConfigurationWizardPage.IntegerConfigurationText;

public class GMRESSolverPage extends MTJIterativeSolverPage {

	
	private IntegerConfigurationText restartText;

	protected GMRESSolverPage(int id) {
		super(id);
		setDescription(WizardMessages.GMRES_DESCRIPTION);
	}

	protected void fillSettingPanel() {
		super.fillSettingPanel();
		Label label = new Label(settingPanel, labelStyle);
		label.setText("Restart");
		label.setLayoutData(new GridData());
		
		restartText.createControl(settingPanel);
		restartText.control.setLayoutData(new GridData(gridDataStyle));
	}
	
	protected void createConfigurationWidgets() {
		super.createConfigurationWidgets();
		restartText = new IntegerConfigurationText(
				OptionMap.GMRES_RESTART);
		this.configurationWidgets.add(restartText);

	}
	
}
