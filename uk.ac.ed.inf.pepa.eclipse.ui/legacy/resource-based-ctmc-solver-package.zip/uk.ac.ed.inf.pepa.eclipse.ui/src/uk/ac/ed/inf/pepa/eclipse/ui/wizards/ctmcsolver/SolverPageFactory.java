package uk.ac.ed.inf.pepa.eclipse.ui.wizards.ctmcsolver;

import java.util.Map;

import uk.ac.ed.inf.pepa.ctmc.solution.OptionMap;

/**
 * Retrieves the solver page for a solver which is specified with the integer as
 * defined in PEPAto
 * 
 * @author mtribast
 * 
 */
public class SolverPageFactory {

	/**
	 * Factory method for solver pages.
	 * 
	 * @param id
	 *            the unique identifier for a solver
	 * @return the solver setting page, or null if none is available
	 */
	public static ISolverPage createPageFor(int id) {
		switch (id) {
			case OptionMap.MTJ_BICG:
			case OptionMap.MTJ_BICG_STAB:
			case OptionMap.MTJ_CG:
			case OptionMap.MTJ_CGS:
			case OptionMap.MTJ_IR:
				return new MTJIterativeSolverPage(id);
			case OptionMap.MTJ_GMRES:
				return new GMRESSolverPage(id);
			case OptionMap.MTJ_DIRECT:
				return new AbstractConfigurationSolverPage("Direct") {
					
					public Map getOptions() {
						Map options = super.getOptions();
						options.put(OptionMap.SOLVER, OptionMap.MTJ_DIRECT);
						return options;
					}
					
					@Override
					protected void fillSettingPanel() {
						// TODO Auto-generated method stub
						
					}

					@Override
					public boolean isNeedPage() {
						return false;
					}
					@Override
					protected void createConfigurationWidgets() {
						
					}
					
				};
			case OptionMap.MTJ_CHEBYSHEV:
				return new ChebyshevSolverPage(id);
		}
		return null;
	}
}
