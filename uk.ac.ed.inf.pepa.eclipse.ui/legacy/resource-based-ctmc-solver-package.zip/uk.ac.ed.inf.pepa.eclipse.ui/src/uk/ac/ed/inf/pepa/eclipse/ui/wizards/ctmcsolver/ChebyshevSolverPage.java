package uk.ac.ed.inf.pepa.eclipse.ui.wizards.ctmcsolver;

import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Label;

import uk.ac.ed.inf.pepa.ctmc.solution.OptionMap;
import uk.ac.ed.inf.pepa.eclipse.ui.wizards.WizardMessages;
import uk.ac.ed.inf.pepa.eclipse.ui.wizards.ctmcsolver.AbstractConfigurationWizardPage.DoubleConfigurationText;

public class ChebyshevSolverPage extends MTJIterativeSolverPage {
	
	private DoubleConfigurationText eigMin;
	private DoubleConfigurationText eigMax;

	protected ChebyshevSolverPage(int id) {
		super(id);
		setDescription(WizardMessages.CHEB_DESCRIPTION);
		/*
		 * Temporary: force the user to set eigenvalue estimates
		 */
		setPageComplete(false);

	}

	protected void fillSettingPanel() {

		super.fillSettingPanel();

				Label minLabel = new Label(settingPanel, labelStyle);
		minLabel.setText("Minimum eigenvalue estimate");
		eigMin.createControl(settingPanel);
		
		minLabel.setLayoutData(new GridData());
		eigMin.control.setLayoutData(new GridData(gridDataStyle));

		Label maxLabel = new Label(settingPanel, labelStyle);
		maxLabel.setText("Maximum eigenvalue estimate");
		eigMax.createControl(settingPanel);
		maxLabel.setLayoutData(new GridData());
		eigMax.control.setLayoutData(new GridData(gridDataStyle));
		
		
	}
	
	protected void createConfigurationWidgets() {
		eigMin = new DoubleConfigurationText(
				OptionMap.CHEB_MIN);
		
		eigMax = new DoubleConfigurationText(
				OptionMap.CHEB_MAX);
		this.configurationWidgets.add(eigMin);
		this.configurationWidgets.add(eigMax);
	
	}	

}
