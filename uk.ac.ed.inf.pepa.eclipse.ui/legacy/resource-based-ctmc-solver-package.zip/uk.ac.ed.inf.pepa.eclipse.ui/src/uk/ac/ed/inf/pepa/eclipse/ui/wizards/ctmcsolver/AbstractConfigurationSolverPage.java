package uk.ac.ed.inf.pepa.eclipse.ui.wizards.ctmcsolver;

import java.util.HashMap;
import java.util.Map;


/**
 * An abstract implementation of the abstract configuration page for
 * {@link ISolverPage}
 * 
 * @author mtribast
 * 
 */
public abstract class AbstractConfigurationSolverPage extends
		AbstractConfigurationWizardPage implements ISolverPage {

	protected AbstractConfigurationSolverPage(String pageName) {
		super(pageName);
	}

	/**
	 * The default implementation creates a Map from the options defined in the
	 * {@link AbstractConfigurationWizardPage#configurationWidgets}
	 * <p>
	 * Can be extended by clients
	 * 
	 * @return the option map for this page
	 */
	// TODO See what to do when a null is returned
	public Map getOptions() {
		Map map = new HashMap();
		
		for (ConfigurationWidget text : configurationWidgets) {
			//System.err.println(text.getProperty() + " : " + text.getValue());
			Object value = text.getValue();
			if (value == null)
				; // FIXME
			map.put(text.getProperty(), value);
		}

		return map;

	}

	public abstract boolean isNeedPage();

}
