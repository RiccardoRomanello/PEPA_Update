package uk.ac.ed.inf.pepa.eclipse.ui.wizards.ctmcsolver;

import java.util.Map;

import org.eclipse.jface.wizard.IWizardPage;

/**
 * This is an interface that any solver page has to implement.
 * <p>
 * If the implemented solver doesn't have a page to show, the
 * {@link #isNeedPage()} must return <code>false</code>. This will cause the
 * wizard no to add the page to the solver. Although the page won't be shown,
 * {@link #getOptions()} must return the correct settings for the solver anyway.
 * 
 * @author mtribast
 * 
 */
public interface ISolverPage extends IWizardPage {

	/**
	 * Return the option map for this solver
	 * 
	 * @return a raw <code>Map</code> containing the options modified by this
	 *         page
	 */
	public Map getOptions();

	/**
	 * Return <code>true</code> when this solver contains widgets.
	 * 
	 * @return
	 */
	public boolean isNeedPage();

}
