package uk.ac.ed.inf.pepa.eclipse.ui.wizards.ctmcsolver;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.Assert;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.Preferences;
import org.eclipse.jface.wizard.IWizard;
import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Text;

import uk.ac.ed.inf.pepa.eclipse.core.PepaLog;
import uk.ac.ed.inf.pepa.eclipse.core.PepatoOptionForwarder;
import uk.ac.ed.inf.pepa.eclipse.ui.wizards.IResourceProvider;

/**
 * This is a wizard page contributing basic behaviour for managing persistency
 * for PEPAto options. The page keeps track of {@link ConfigurationWidget},
 * which are objects containing SWT Widgets manipulating persistent option.
 * These objects expose methods for initialising their status from a
 * {@link IResource}'s persistent settings or, if none, from the plug-in's
 * default preferences.
 * <p>
 * The resource this pages uses must be provided by the containing wizard, which
 * must implement the {@link IResourceProvider} interface. If no resource is
 * provided, the configuration widgets will be initialised using the plug-in
 * preferences.
 * <p>
 * The page provides a basic GridLayout with 2 columns, which is expected to be
 * filled as pairs [label, configuration widget], the label describing the
 * option which can be set. Changes to the configuration widget are notified to
 * a unique listener which validates the form and set the status of the
 * completion of this page.
 * 
 * @author mtribast
 * 
 */
public abstract class AbstractConfigurationWizardPage extends WizardPage {

	private static final Preferences preferences = uk.ac.ed.inf.pepa.eclipse.core.PepaCore
			.getDefault().getPluginPreferences();

	abstract class ConfigurationWidget {

		protected String propertyKey;

		protected String propertyValue;

		protected Control control;

		ConfigurationWidget(String key) {

			Assert.isNotNull(key);

			this.propertyKey = key;
			this.control = null;
			this.propertyValue = null;

			init();

		}

		public String getProperty() {
			return propertyKey;
		}

		abstract Control createControl(Composite parent);
		
		/**
		 * Reconcile the control with the internal model
		 *
		 */
		abstract void updateControl();
		

		/**
		 * Parses the value contained by this widget and return the correct
		 * object, which may be a String, a Double, a Long, etc.
		 * 
		 * @return
		 */
		abstract Object getValue();

		/**
		 * Set the value of the widget to the passed string. It is up to
		 * concrete implementations to treat the string properly.
		 * 
		 * @param value
		 */
		abstract void setValue(String value);

		abstract boolean isValid();

		abstract void resetToDefault();

		void init() {

			String persistentOption = null;

			if (resource != null) {
				try {
					persistentOption = PepatoOptionForwarder
							.getOptionFromPersistentResource(resource,
									(String) this.propertyKey);
					if (persistentOption != null)
						setValue(persistentOption);
				} catch (CoreException e) {
					PepaLog.logError(e);
				}

			}
			if (persistentOption == null) {
				initFromPreferences();
			}
		}

		abstract void initFromPreferences();

	}

	class ConfigurationCheckBox extends ConfigurationWidget {

		ConfigurationCheckBox(String key) {
			super(key);
		}

		@Override
		Object getValue() {
			return Boolean.parseBoolean(this.propertyValue);
		}

		@Override
		void setValue(String value) {
			this.propertyValue = value;
		}

		@Override
		boolean isValid() {

			return true;
		}

		@Override
		void resetToDefault() {
			initFromPreferences();
		}

		@Override
		void initFromPreferences() {
			this.propertyValue = ""
					+ preferences.getDefaultBoolean(this.propertyKey);
		}

		@Override
		Control createControl(Composite parent) {
			control = new Button(parent, SWT.CHECK);
			control.addListener(SWT.Modify, new Listener() {

				public void handleEvent(Event event) {
					setValue(Boolean
							.toString(((Button) control).getSelection()));
					validateForm();
				}

			});
			updateControl();
			return control;

		}

		@Override
		void updateControl() {
			if (control != null)
				((Button) control).setSelection((Boolean) getValue());
		}
	}

	abstract class ConfigurationText extends ConfigurationWidget {

		ConfigurationText(String key) {
			super(key);
		}

		void setValue(String value) {
			this.propertyValue = value;
		}

		Control createControl(Composite parent) {

			control = new Text(parent, textStyle);
			control.addListener(SWT.Modify, new Listener() {

				public void handleEvent(Event event) {
					setValue(((Text) control).getText());
					validateForm();
				}

			});
			updateControl();
			return control;

		}
		
		public void updateControl() {
			((Text) control).setText("" + getValue());
			
		}

	}

	class DoubleConfigurationText extends ConfigurationText {

		DoubleConfigurationText(String key) {
			super(key);
		}

		@Override
		boolean isValid() {
			try {
				Double.parseDouble(this.propertyValue);
			} catch (NumberFormatException e) {
				return false;
			}
			return true;
		}

		@Override
		Object getValue() {
			try {
				return Double.parseDouble(this.propertyValue);
			} catch (NumberFormatException e) {
				return null;
			}
		}

		@Override
		void resetToDefault() {
			this.propertyValue = ""
					+ preferences.getDefaultDouble((String) this.propertyKey);
		}

		@Override
		void initFromPreferences() {
			resetToDefault();
		}
	}

	class IntegerConfigurationText extends ConfigurationText {

		IntegerConfigurationText(String key) {
			super(key);
		}

		@Override
		boolean isValid() {
			try {
				Integer.parseInt(this.propertyValue);
			} catch (NumberFormatException e) {
				return false;
			}
			return true;
		}

		@Override
		Object getValue() {
			try {
				return Integer.parseInt(this.propertyValue);
			} catch (NumberFormatException e) {
				return null;
			}
		}

		@Override
		void resetToDefault() {
			this.propertyValue = ""
					+ preferences.getDefaultInt((String) this.propertyKey);
		}

		void initFromPreferences() {
			resetToDefault();
		}

	}

	/**
	 * The list of configuration widgets managed by this page
	 */
	protected final List<ConfigurationWidget> configurationWidgets = new ArrayList<ConfigurationWidget>();

	/**
	 * The Composite with the GridLayout which accepts new configuration
	 * widgets.
	 */
	protected Composite settingPanel;

	protected int textStyle = SWT.BORDER | SWT.RIGHT;;

	protected int labelStyle = SWT.RIGHT;

	protected int gridDataStyle = GridData.FILL_HORIZONTAL
			| GridData.GRAB_HORIZONTAL;

	/**
	 * The underlying resource from which default settings are taken. It is
	 * lazily initialised to the resource provided by the wizard, if any.
	 */
	protected IResource resource = null;

	/**
	 * Create a Wizard Page containing widgets for modifying configuration
	 * settings. The default values are taken from the plugin preference store.
	 * The widgets are initialised using the resource persistent values, if a
	 * resource is passed. If no resource is passed in, then the widgets are
	 * initialised using the preference store's current values.
	 * 
	 * @param pageName
	 *            page name
	 * @param resource
	 *            resource to look up for initialisation values. It may be null,
	 *            meaning that the preference store's current settings will be
	 *            used at initialisation.
	 */
	protected AbstractConfigurationWizardPage(String pageName) {
		super(pageName);
	}
	
	public void setWizard(IWizard wizard) {
		super.setWizard(wizard);
		/* caches the resource */
		if (wizard instanceof IResourceProvider)
			resource = ((IResourceProvider) wizard).getResource();
		else
			resource = null;
		
		createConfigurationWidgets();

	}

	public final void createControl(Composite parent) {

		settingPanel = new Composite(parent, SWT.NONE);

		GridLayout layout = new GridLayout();
		layout.numColumns = 2;
		settingPanel.setLayout(layout);
		setControl(settingPanel);

		fillSettingPanel();

		Button reset = new Button(settingPanel, SWT.NONE);
		reset.setText("Reset to defaults");

		GridData resetData = new GridData();
		resetData.horizontalSpan = 2;
		resetData.verticalSpan = 1;
		resetData.horizontalAlignment = SWT.RIGHT;
		reset.setLayoutData(resetData);
		reset.addListener(SWT.Selection, new Listener() {
			public void handleEvent(Event event) {
				resetToDefaults();
			}
		});

		validateForm();

	}

	/**
	 * The standard implementation calls
	 * {@link ConfigurationWidget#resetToDefault()} on all the managed widgets
	 * 
	 */
	protected void resetToDefaults() {
		for (ConfigurationWidget widget : configurationWidgets) {
			widget.resetToDefault();
			widget.updateControl();
		}
	}

	/**
	 * Implementors add configuration widgets to the setting panel. Each
	 * configuration widget must be esplicitely added to the list by calling
	 * <code>add</code> on {@link #configurationWidgets}
	 * 
	 */
	abstract protected void fillSettingPanel();

	abstract protected void createConfigurationWidgets();

	/**
	 * This method is called when one of the configuration texts is changed. It
	 * calls <code>ConfigurationText#isValid()</code> and sets the error
	 * message of the page when one of these checks fails.
	 * <p>
	 * This method can be extended by users.
	 * 
	 */
	protected void validateForm() {
		setPageComplete(false);
		setErrorMessage(null);

		boolean validation = true;
		for (ConfigurationWidget widget : configurationWidgets) {
			validation = widget.isValid();
			if (!validation) {
				setErrorMessage("Value not allowed");
				break;
			}
		}
		setPageComplete(validation);
	}

}
