package uk.ac.ed.inf.pepa.eclipse.ui.wizards.ctmcsolver;

import java.lang.reflect.InvocationTargetException;
import java.util.Collection;
import java.util.Map;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.jface.wizard.IWizardPage;
import org.eclipse.jface.wizard.Wizard;
import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Listener;

import uk.ac.ed.inf.pepa.ctmc.solution.OptionMap;
import uk.ac.ed.inf.pepa.ctmc.solution.SolverException;
import uk.ac.ed.inf.pepa.eclipse.core.IPepaModel;
import uk.ac.ed.inf.pepa.eclipse.core.PepaCore;
import uk.ac.ed.inf.pepa.eclipse.core.PepaLog;
import uk.ac.ed.inf.pepa.eclipse.core.PepatoOptionForwarder;
import uk.ac.ed.inf.pepa.eclipse.ui.wizards.IResourceProvider;
import uk.ac.ed.inf.pepa.eclipse.ui.wizards.WizardMessages;

/**
 * Open the wizard for setting solver parameters for steady-state analysis of
 * the underlying CTMC of a PEPA model and provide services for storing these
 * data to disk.
 * 
 * @author mtribast
 * 
 */
public class SolverWizard extends Wizard implements IResourceProvider {

	IPepaModel model;

	private SolverSelectionPage selectSolverPage;

	/**
	 * Create the wizard and passes the model on which CTMC steady-state
	 * analysis has to be carried out.
	 * <p>
	 * A model with a correctly derived state space has to be given.
	 * 
	 * @param model
	 *            the PEPA model
	 * @throws IllegalArgumentException
	 *             if the model is not solvable
	 * @throws NullPointerException
	 *             if the given model is <code>null</code>
	 */
	public SolverWizard(IPepaModel model) {
		super();
		if (model == null)
			throw new NullPointerException(
					"Model passed to the solver wizard cannot be null");
		if (!model.isSolvable())
			throw new IllegalArgumentException("Model is not solvable.");
		this.model = model;

	}

	public boolean canFinish() {
		/* Finish only on linked pages */
		IWizardPage page = selectSolverPage;
		while (page != null) {
			if (!page.isPageComplete())
				return false;
			page = page.getNextPage();
		}
		return true;
	}

	@Override
	public void addPages() {

		setForcePreviousAndNextButtons(true);
		setWindowTitle(WizardMessages.STEADY_STATE_CTMC_WIZARD_TITLE);
		setHelpAvailable(false);
		setNeedsProgressMonitor(true);
		selectSolverPage = new SolverSelectionPage();
		addPage(selectSolverPage);

	}

	@Override
	/*
	 * If returns false, the dialog won't close.
	 */
	public boolean performFinish() {

		final OptionMap options = new OptionMap(selectSolverPage.solverPage
				.getOptions());

		// ===============================================================
		// Save the model
		// ===============================================================
		try {
			getContainer().run(false, false, new IRunnableWithProgress() {

				public void run(IProgressMonitor monitor)
						throws InvocationTargetException, InterruptedException {
					try {
						model.setOptionMap(options);
						model.solveCTMCSteadyState(monitor);
					} catch (SolverException e) {
						throw new InvocationTargetException(e);
					}
				}

			});
		} catch (InvocationTargetException e1) {
			String message = e1.getCause().getMessage();
			if (message == null || message.equals("")) {
				message = "An error occurred while solving the model.";
				message += "\n" + e1.getCause();
			}
			MessageDialog.openError(getShell(), "Solver error", message);
			return false;
		} catch (InterruptedException e1) {
			return false;
		}

		// ===============================================================
		// Save the solver settings
		// ===============================================================
		try {
			saveResourceOptions(selectSolverPage.solverPage.getOptions());
		} catch (CoreException e1) {
			PepaLog.logError(e1);
			MessageDialog.openError(getShell(), "Core Exception",
					"Error saving resource settings:\n" + e1.getMessage());
			// doesn't return, try to save the solution
		}
		return true;
	}

	/**
	 * Save this settings in a persistent manner
	 * 
	 * @param options
	 * @throws CoreException
	 */
	private void saveResourceOptions(Map options) throws CoreException {
		for (Object key : options.keySet())
			PepatoOptionForwarder.saveOptionInPersistentResource(model
					.getUnderlyingResource(), (String) key, options.get(key));
	}

	public IResource getResource() {
		return model.getUnderlyingResource();
	}

}

class SolverSelectionPage extends WizardPage {

	ISolverPage solverPage = null;

	private String currentSolverSelected = null;

	private Combo solvers;

	/**
	 * Constructor for the first page of the wizard
	 * 
	 * @param resource
	 *            the file where the model is stored
	 */
	protected SolverSelectionPage() {
		super("selectSolver");
		setTitle(WizardMessages.STEADY_STATE_CTMC_SOLVERS_PAGE_TITLE);
		setDescription(WizardMessages.STEADY_STATE_CTMC_SOLVERS_PAGE_DESCRIPTION);

	}

	public void createControl(Composite parent) {

		Composite composite = new Composite(parent, SWT.NULL);
		GridLayout layout = new GridLayout();
		layout.numColumns = 3;
		layout.verticalSpacing = 5;
		composite.setLayout(layout);
		setControl(composite);

		Label solverLabel = new Label(composite, SWT.NONE);
		solverLabel.setText("Choose solver");
		GridData solverData = new GridData();
		solverData.horizontalSpan = 3;
		solverData.grabExcessHorizontalSpace = true;
		solverData.grabExcessVerticalSpace = false;
		solverLabel.setLayoutData(solverData);

		solvers = new Combo(composite, SWT.READ_ONLY);
		GridData comboData = new GridData();
		comboData.horizontalSpan = 3;
		comboData.grabExcessHorizontalSpace = true;
		comboData.grabExcessVerticalSpace = false;
		solvers.setLayoutData(comboData);

		populateSolverCombo(solvers);

		setPageComplete(false);

		initSettings();

	}

	@Override
	public IWizardPage getNextPage() {
		if (this.solverPage != null && this.solverPage.isNeedPage())
			return this.solverPage;
		else
			return null;
	}

	private void initSettings() {

		String option = null;
		try {
			option = PepatoOptionForwarder.getOptionFromPersistentResource(
					((IResourceProvider) getWizard()).getResource(),
					OptionMap.SOLVER);
		} catch (CoreException e) {
		}
		if (option == null)
			resetSolverToDefaults();
		else {
			setSolver(Integer.parseInt(option));
		}
	}

	private void resetSolverToDefaults() {
		int defaultId = PepaCore.getDefault().getPluginPreferences()
				.getDefaultInt(OptionMap.SOLVER);
		setSolver(defaultId);
	}

	private void setSolver(int id) {
		String name = Solvers.getInstance().getSolverName(id);
		solvers.setText(name);
		newSolverSelected(name);
	}

	private void newSolverSelected(String solverSelected) {
		setPageComplete(false);
		// solver = manager.getClassSolver(solverSelected);
		Integer id = Solvers.getInstance().getSolverId(solverSelected);
		ISolverPage solverPage = SolverPageFactory.createPageFor(id);
		if (solverPage == null) {
			/* An unexpected error occurred */
			setMessage(null);
			String error = "No solver available";
			setErrorMessage(error);
			return;
		}

		if (this.solverPage != null
				&& solverSelected.equals(currentSolverSelected)) {
			/*
			 * a page is already set and that's the same as the currently cached
			 * one
			 */

		} else {
			/* a page was not set or a different one has been selected */
			this.solverPage = solverPage;
			if (this.solverPage.isNeedPage())
				((Wizard) getWizard()).addPage(solverPage);

		}
		this.currentSolverSelected = solverSelected;

		setMessage(null);
		setErrorMessage(null);
		setPageComplete(true);
	}

	/**
	 * The combo is populated with the name of the available solvers
	 */
	private void populateSolverCombo(final Combo solvers) {
		Collection<String> solverStrings = Solvers.getInstance()
				.getAvailableSolvers();
		for (String solver : solverStrings) {
			solvers.add(solver);
		}

		solvers.addListener(SWT.Selection, new Listener() {
			public void handleEvent(Event event) {
				newSolverSelected(solvers.getText());
			}
		});
	}

}
